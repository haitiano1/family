<?php return ['version'=>'0.32.12','schema'=>8,'protocol'=>1];
