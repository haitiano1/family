<?php return ['version'=>'0.32.10','schema'=>8,'protocol'=>1];
