// Tra cứu & chuyển nhóm — admin side: Family status shown to customers, invite link pools,
// bulk moves (one invite per customer), move progress and the customer lookup page settings.
import { familyStatusLabels, inviteExpiry, familyOccupancy, sortCustomers } from './domain.js';

const $ = selector => document.querySelector(selector);
const statusColors = { active: 'green', checking: 'amber', scanned: 'amber', disabled: 'red' };
const problem = status => status && status !== 'active';
const moveStates = {
  // Giving the customer their link is the end of the shop's work; joining is not tracked.
  assigned: ['blue', 'Đã giao link'], opened: ['green', 'Khách đã mở link'], failed: ['blue', 'Đã giao link'],
  joined: ['green', 'Đã vào nhóm'], cancelled: ['', 'Đã thu hồi link'], stale: ['', 'Khách đã chuyển hoặc bị xóa'],
  waiting: ['amber', 'Chờ link · khách tra cứu là nhận']
};
export const reportLabels = { twelve_months: 'Google báo chỉ được đổi nhóm 1 lần trong 12 tháng', invite_used: 'Lời mời đã dùng hoặc hết hạn', other_family: 'Khách đang ở nhóm gia đình khác', other: 'Lỗi khác' };
const statusTemplates = {
  checking: name => `Shop đang kiểm tra sự cố của ${name}. Bạn chưa cần làm gì, shop sẽ cập nhật tại đây.`,
  scanned: name => `${name} bị Google quét nên một số thành viên mất Premium. Shop đang chuyển bạn sang nhóm mới, hạn dùng giữ nguyên.`,
  disabled: name => `Tài khoản chủ của ${name} bị Google vô hiệu hoá. Shop đang chuyển bạn sang nhóm mới, hạn dùng giữ nguyên.`
};

// The page link the shop shares: the short link when one is set (beeflix.vn/haiytb), else this site.
export const lookupPageUrl = (state = {}) => { const base = state.lookup_settings?.short_domain; return base ? (/^https?:\/\/[^/]+\/./.test(base) ? base : base + '/') : location.origin + '/tra-cuu.html'; };
export function familyStatus(state, familyId) {
  return (state.family_statuses || []).find(s => s.family_id === familyId) || { family_id: familyId, status: 'active', note: '', updated_at: '', revision: 0 };
}
const codeOf = (state, address) => state.lookup_codes?.[address] || '';
// Short link the shop sends: https://domain/?K7P2QX (older #ma= links keep working).
// With a path (beeflix.vn/haiytb) the code follows directly: beeflix.vn/haiytb?K7P2QX.
const personalLink = (state, code) => { const base = state.lookup_settings?.short_domain || location.origin; return /^https?:\/\/[^/]+\/./.test(base) ? `${base}?${code}` : `${base}/?${code}`; };
export function lookupMessage(state, member) {
  const code = codeOf(state, member.email); if (!code) return '';
  return `Link tra cứu Family của bạn: ${personalLink(state, code)}\nGmail: ${member.email} · Mã tra cứu: ${code}\nKhi YouTube Premium có vấn đề, mở link bằng Chrome hoặc Safari để xem tình trạng nhóm và nhận link vào nhóm mới.`;
}
const isJoin = move => move.from_family_id == null && !move.from_family_name;
function moveMessage(state, move) {
  const code = codeOf(state, move.email); if (!code) return '';
  // Customers never see Family names (the shop names them to remember them).
  if (isJoin(move)) return `Chào bạn, link vào nhóm của bạn ở đây. Mở bằng Chrome hoặc Safari, nhập Gmail ${move.email}: ${personalLink(state, code)}\nMã tra cứu: ${code}`;
  return `Chào bạn, nhóm YouTube của bạn đang gặp sự cố nên shop đã chuẩn bị nhóm mới, hạn dùng giữ nguyên. Mở link này bằng Chrome hoặc Safari, nhập Gmail ${move.email} để lấy link vào nhóm mới: ${personalLink(state, code)}\nMã tra cứu: ${code}`;
}
// Result of Lấy link từ Gmail (button and the 10-minute check in sheets.js).
export function gmailSummary(result) {
  const parts = [];
  if (result.added) parts.push(`thêm ${result.added} link`);
  if (result.updated) parts.push(`cập nhật ${result.updated} link`);
  let text = parts.length ? `Đã ${parts.join(', ')} từ Gmail${result.families?.length ? ' cho ' + result.families.join(', ') : ''}.` : result.found ? 'Link mời trong Gmail đã có đủ trên web.' : 'Không thấy thư mời Family nào trong 14 ngày qua.';
  if (result.unmatched_count) text += ` ${result.unmatched_count} thư chưa khớp mail chủ Family nào (${result.unmatched.slice(0, 3).join(', ')}${result.unmatched_count > 3 ? '…' : ''}).`;
  return text;
}
const gmailButton = ctx => ctx.state.gmail_import ? ctx.btn('invites-gmail', 'Lấy link từ Gmail', 'secondary', 'title="Đọc thư mời Family trong Gmail 14 ngày qua và thêm link vào đúng Family"') : '';

// ---- Gen mail mời: + addresses on the shop's Gmail, then their links from Gmail ----
const DAY = 86400000;
const inviteFor = (state, address) => (state.invites || []).filter(i => String(i.label).toLowerCase() === address).at(-1);
// Addresses made in the last 14 days (an invitation lasts two weeks), newest first.
const recentMails = (state, familyId) => (state.invite_mails || []).filter(m => m.family_id === familyId && Date.now() - Date.parse(m.created_at) < 14 * DAY).sort((a, b) => b.created_at.localeCompare(a.created_at) || a.id - b.id);
const pendingMails = (state, familyId) => recentMails(state, familyId).filter(m => !inviteFor(state, m.email));
const suggestedCount = (state, familyId) => Math.min(5, Math.max(1, 5 - familyOccupancy(state.members, familyId).occupied));
// Add Family: pick how many addresses to make together with the Family (all on the shop Gmail).
export function inviteMailFields(ctx) {
  const { state, escape } = ctx;
  return `<div class="form-field"><label for="field-invite_count">Gen mail mời</label><select id="field-invite_count" name="invite_count">${[[0, 'Không tạo'], ...[1, 2, 3, 4, 5].map(n => [n, n + ' mail'])].map(([value, text]) => `<option value="${value}">${text}</option>`).join('')}</select></div>`
    + `<p class="subtext">Tạo luôn khi lưu Family: ${escape(state.invite_base_email || 'haihoangrr@gmail.com').replace('@', '+<em>đuôi ngẫu nhiên</em>@')}, không bao giờ trùng mail đã tạo.</p>`;
}
export async function createInviteMails(ctx, familyId, count) {
  count = Number(count); if (!count) return null;
  return ctx.post(`families/${familyId}/invite-mails`, { count });
}
// Family page: choosing a number creates the addresses at once.
const genMenu = (ctx, family) => `<details class="gen-menu"><summary class="secondary">Gen mail mời</summary><div class="gen-menu-list" role="group" aria-label="Số mail mời cần tạo">${[1, 2, 3, 4, 5].map(n => ctx.btn('invite-mails-gen', n + ' mail', 'secondary tiny', `data-id="${family.id}" data-count="${n}"`)).join('')}</div></details>`;
export function showInviteMails(ctx, result) {
  const { escape, state } = ctx, family = state.families.find(f => f.id === result.family_id), all = result.mails.join(', ');
  ctx.modal('Mail mời · ' + result.family_name, `<p>Đã tạo ${result.mails.length} mail mời mới.</p><div class="lookup-mail-list">${result.mails.map(address => `<div class="info-line"><strong class="info-text">${escape(address)}</strong>${ctx.copyButton(address, 'mail mời')}</div>`).join('')}</div><div class="row-actions">${ctx.copyButton(all, 'tất cả mail mời', 'Copy tất cả mail')}</div>`
    + `<ol class="lookup-steps"><li>Đăng nhập tài khoản chủ Family${family ? ` <strong>${escape(family.manager_email)}</strong>` : ''}, mở trang quản lý nhóm gia đình và mời các mail trên.</li><li>${state.gmail_import ? 'Quay lại Family này, bấm <strong>Lấy link mời</strong>: web hiện link của từng mail và lưu vào kho link.' : 'Mở từng thư mời trong Gmail, chuột phải nút Accept invitation → sao chép link, rồi bấm <strong>+ Thêm link mời</strong>.'}</li></ol>`, async () => {}, 'Đóng');
}
function fetchedMailsTable(ctx, familyId) {
  const { state, escape } = ctx, mails = recentMails(state, familyId);
  if (!mails.length) return '<p class="muted">Family này chưa có mail mời tạo trong 14 ngày qua. Bấm Gen mail mời để tạo.</p>';
  const rows = mails.map(m => {
    const invite = inviteFor(state, m.email), elsewhere = invite && invite.family_id !== familyId ? state.families.find(f => f.id === invite.family_id) : null;
    const status = !invite ? '<span class="badge amber">Chưa thấy thư mời</span>' : inviteStateBadge(ctx, invite) + (elsewhere ? `<span class="subtext">Lưu ở ${escape(elsewhere.name)} vì thư được mời từ chủ Family đó</span>` : '');
    return `<tr><td data-column="mail"><div class="info-line"><strong class="info-text">${escape(m.email)}</strong>${ctx.copyButton(m.email, 'mail mời')}</div></td><td data-column="invite">${invite ? `<span class="subtext lookup-url">${escape(invite.url)}</span>` : '<span class="subtext">—</span>'}</td><td data-column="state">${status}</td><td data-column="actions">${invite ? ctx.copyButton(invite.url, 'link mời', 'Copy link') : ''}</td></tr>`;
  }).join('');
  const links = mails.map(m => [m.email, inviteFor(state, m.email)]).filter(([, i]) => i).map(([address, i]) => `${address}: ${i.url}`).join('\n');
  return `<div class="table-wrap"><table class="lookup-table"><thead><tr><th scope="col">MAIL MỜI</th><th scope="col">LINK MỜI</th><th scope="col">TRẠNG THÁI</th><th scope="col"></th></tr></thead><tbody>${rows}</tbody></table></div>${links ? `<div class="row-actions">${ctx.copyButton(links, 'tất cả link mời', 'Copy tất cả link')}</div>` : ''}`;
}
function showFetchedMails(ctx, family, result) {
  const { state, escape } = ctx, bases = [...new Set(recentMails(state, family.id).map(m => m.email.replace(/\+[^@]*@/, '@')))];
  const wrongBox = result.mailbox && bases.length && !bases.includes(result.mailbox) ? `<p class="error-box">Apps Script đang đọc Gmail ${escape(result.mailbox)}, còn mail mời của Family này thuộc ${escape(bases.join(', '))}. Thư mời gửi tới Gmail khác sẽ không được thấy.</p>` : '';
  const moved = (result.mismatched || []).filter(m => recentMails(state, family.id).some(r => r.email === m.email));
  ctx.modal('Link mời · ' + family.name, `<p>${escape(gmailSummary(result))}</p>${wrongBox}${moved.length ? `<p class="notice">${moved.map(m => `${escape(m.email)} được mời từ chủ ${escape(m.invited_by)}, nên link lưu ở ${escape(m.invited_by)}.`).join(' ')}</p>` : ''}${fetchedMailsTable(ctx, family.id)}`, async () => {}, 'Đóng');
  const dialog = $('#modal'); dialog.classList.add('lookup-wide'); dialog.addEventListener('close', () => dialog.classList.remove('lookup-wide'), { once: true });
}
function pendingNotice(ctx, family) {
  const mails = pendingMails(ctx.state, family.id); if (!mails.length) return '';
  const { escape } = ctx;
  return `<div class="notice lookup-callout lookup-pending-mails"><div><strong>${mails.length} mail chờ lấy link</strong><span class="subtext">Mời các mail này từ tài khoản chủ ${escape(family.manager_email)}, rồi bấm ${ctx.state.gmail_import ? 'Lấy link mời' : '+ Thêm link mời để dán link'}.</span><div class="lookup-mail-list">${mails.map(m => `<div class="info-line"><span class="info-text">${escape(m.email)}</span>${ctx.copyButton(m.email, 'mail mời')}<button type="button" class="copy-info lookup-mail-delete" data-action="invite-mails-delete" data-id="${family.id}" data-mails="${m.id}" title="Xóa ${escape(m.email)}" aria-label="Xóa ${escape(m.email)}">×</button></div>`).join('')}</div></div><div class="row-actions lookup-pending-actions">${ctx.copyButton(mails.map(m => m.email).join(', '), 'tất cả mail chờ mời', 'Copy tất cả mail')}${ctx.btn('invite-mails-delete', mails.length > 1 ? 'Xóa tất cả' : 'Xóa mail', 'danger tiny', `data-id="${family.id}" data-mails="${mails.map(m => m.id).join(',')}"`)}</div></div>`;
}
export function familyStatusBadge(ctx, familyId) {
  const status = familyStatus(ctx.state, familyId).status;
  return problem(status) ? `<span class="badge ${statusColors[status]} lookup-family-badge">${ctx.escape(familyStatusLabels[status])}</span>` : '';
}
export function customerLookupAction(ctx, member) {
  const message = lookupMessage(ctx.state, member);
  return message ? ctx.copyButton(message, 'link tra cứu của khách', 'Copy link tra cứu') + ctx.btn('lookup-rotate', 'Đổi mã tra cứu', 'secondary tiny', `data-email="${ctx.escape(member.email)}"`) : '';
}

const readyInvites = (state, familyId) => (state.invites || []).filter(i => i.family_id === familyId && i.holder_state === 'ready');
const inviteName = (ctx, invite) => invite.label || 'Link #' + invite.id;
// Once a customer joined with a link, the row shows that customer's Gmail instead of the + address.
const inviteTitle = (ctx, invite) => invite.holder_state === 'used' && invite.holder_email
  ? `<strong>${ctx.escape(invite.holder_email)}</strong><span class="subtext">Mail mời: ${ctx.escape(inviteName(ctx, invite))}</span>`
  : `<strong>${ctx.escape(inviteName(ctx, invite))}</strong>`;
function inviteStateBadge(ctx, invite) {
  if (invite.holder_state === 'retired') return `<span class="badge">Link chủ cũ</span><span class="subtext">Không giao cho khách</span>`;
  if (invite.holder_state === 'used') return `<span class="badge green">Đã dùng</span><span class="subtext">${ctx.escape(invite.holder_name || invite.holder_email)}</span>`;
  // Đã gửi is set by the web itself: a link handed to a customer (lookup page or a move).
  if (invite.holder_state === 'assigned') {
    // Whether the customer pressed Vào nhóm mới is the only signal: an unclicked link can go to someone else.
    const move = (ctx.state.moves || []).find(m => m.id === invite.holder_move_id), clicked = move?.opened_at;
    const days = invite.sent_at ? Math.floor((Date.now() - Date.parse(invite.sent_at)) / 86400000) : 0;
    return `<span class="badge ${clicked ? 'green' : 'amber'}">${clicked ? 'Khách đã bấm link' : 'Khách chưa bấm link'}</span><span class="subtext">${ctx.escape(invite.holder_name || invite.holder_email)}</span><span class="subtext">${clicked ? 'Bấm lúc ' + ctx.date(move.opened_at) : invite.sent_at ? `Giao ${days ? days + ' ngày trước' : 'hôm nay'}` : 'Khách chưa mở trang tra cứu'}</span>`;
  }
  if (invite.holder_state === 'sent') return `<span class="badge amber">Đã gửi</span><span class="subtext">Lúc ${ctx.date(invite.sent_at)} · không giao lại</span>`;
  return '<span class="badge">Sẵn sàng</span>';
}
// A link that was shown to someone and is no longer held (e.g. after Đổi link) stays out of
// the pool until the owner puts it back.
const unsendButton = (ctx, invite) => invite.holder_state === 'sent' ? ctx.btn('invite-unsend', 'Đưa lại vào kho', 'secondary tiny', `data-id="${invite.id}" title="Link này chưa ai dùng: cho phép giao cho khách khác"`) : '';
function expiryText(ctx, invite) {
  if (!invite.sent_on) return '<span class="subtext">Chưa nhập ngày gửi</span>';
  const left = Math.round((Date.parse(invite.expires_on) - Date.parse(ctx.state.today)) / 86400000);
  const badge = left < 0 ? `<span class="badge red">Đã hết hạn</span>` : left <= 2 ? `<span class="badge amber">Còn ${left} ngày</span>` : `<span class="badge green">Còn ${left} ngày</span>`;
  return `<strong class="date-value">${ctx.day(invite.expires_on)}</strong><span class="subtext">${badge}</span>`;
}
function inviteTable(ctx, invites) {
  const { escape, btn } = ctx;
  if (!invites.length) return '<p class="muted">Chưa có link mời. Gửi lời mời từ tài khoản chủ Family tới các mail của bạn (ví dụ mail+1, mail+2…), rồi dán link nút <strong>Chấp nhận lời mời</strong> vào đây.</p>';
  return `<div class="table-wrap"><table class="lookup-table"><thead><tr><th scope="col">LINK MỜI</th><th scope="col">LỜI MỜI HẾT HẠN</th><th scope="col">TRẠNG THÁI</th><th scope="col">THAO TÁC</th></tr></thead><tbody>${invites.map(i => `<tr><td data-column="invite">${inviteTitle(ctx, i)}<span class="subtext lookup-url">${escape(i.url)}</span></td><td data-column="expiry" class="date-cell">${expiryText(ctx, i)}</td><td data-column="state">${inviteStateBadge(ctx, i)}</td><td data-column="actions"><div class="row-actions">${unsendButton(ctx, i)}${i.holder_state === 'assigned' && !(ctx.state.moves || []).find(m => m.id === i.holder_move_id)?.opened_at ? btn('move-unassign', 'Thu hồi về kho', 'secondary tiny', `data-id="${i.holder_move_id}" title="Khách chưa bấm link: giao link này cho khách khác, khách cũ chờ link mới"`) : ''}${ctx.copyButton(i.url, 'link mời', 'Copy link')}${btn('invite-edit', 'Sửa', 'secondary tiny', `data-id="${i.id}"`)}${i.holder_state === 'assigned' ? '' : btn('invite-delete', 'Xóa', 'danger tiny', `data-id="${i.id}"`)}</div></td></tr>`).join('')}</tbody></table></div>`;
}
function moveBadge(ctx, move) {
  const key = move.effective_state === 'assigned' && move.invite_id == null ? 'waiting' : move.effective_state;
  const [color, text] = moveStates[key] || ['', move.effective_state];
  return `<span class="badge ${color}">${text}</span>`;
}
function moveTable(ctx, moves, showTarget = false) {
  const { escape, btn, state } = ctx;
  if (!moves.length) return '<p class="muted">Chưa có khách chuyển nhóm.</p>';
  return `<div class="table-wrap"><table class="lookup-table"><thead><tr><th scope="col">KHÁCH</th><th scope="col">${showTarget ? 'TỪ → ĐẾN' : 'TỪ FAMILY'}</th><th scope="col">LINK</th><th scope="col">TIẾN ĐỘ</th><th scope="col">THAO TÁC</th></tr></thead><tbody>${moves.map(move => {
    const open = ['assigned', 'opened', 'failed'].includes(move.effective_state);
    const message = open ? moveMessage(state, move) : '';
    const actions = open
      ? (message ? ctx.copyButton(message, 'tin nhắn gửi khách', 'Copy tin nhắn') : '') + ctx.moreActions('Thao tác khác cho ' + (move.customer_name || move.email), btn('move-reassign', 'Đổi link', 'secondary tiny', `data-id="${move.id}"`) + (move.invite_id != null && !move.opened_at ? btn('move-unassign', 'Thu hồi về kho', 'secondary tiny', `data-id="${move.id}"`) : '') + btn('move-release', 'Thu hồi link', 'danger tiny', `data-id="${move.id}"`))
      : btn('move-dismiss', 'Ẩn', 'secondary tiny', `data-id="${move.id}"`) + (move.effective_state === 'stale' ? btn('move-release', 'Thu hồi link', 'secondary tiny', `data-id="${move.id}"`) : '');
    return `<tr><td data-column="customer">${ctx.customerInfo({ customer_name: move.customer_name, email: move.email }, false)}</td><td data-column="family">${isJoin(move) ? '<span class="subtext">Khách mới · tự nhận link</span>' : escape(move.from_family_name)}${showTarget ? ` → <a class="email-link" href="#family/${move.to_family_id}">${escape(move.to_family_name)}</a>` : ''}</td><td data-column="invite">${escape(move.invite_label || (move.invite_id ? 'Link #' + move.invite_id : '—'))}</td><td data-column="state">${moveBadge(ctx, move)}<span class="subtext">Cập nhật ${ctx.date(move.updated_at)}</span></td><td data-column="actions"><div class="row-actions">${actions}</div></td></tr>`;
  }).join('')}</tbody></table></div>`;
}

// ---- Khách báo mất Premium (customer reports) ----
const openReports = state => (state.customer_reports || []).filter(r => !r.handled_at);
const reasonLabel = (state, reason) => (state.problem_reasons || {})[reason] || reason;
export function customerReportsCount(state) { return openReports(state).length; }
export function customerReportsNotice(ctx) {
  const count = openReports(ctx.state).length; if (!count) return '';
  const families = new Set(openReports(ctx.state).map(r => r.family_id)).size;
  return `<a class="notice report-alert" href="#issues"><span class="report-alert-dot" aria-hidden="true"></span><span><strong>${count} khách báo mất Premium</strong><span class="subtext">${families > 1 ? `Ở ${families} Family. ` : ''}Mở Fix lỗi để xem và xử lý.</span></span></a>`;
}
export function customerReportsSection(ctx) {
  const { state, escape, btn } = ctx, rows = openReports(state);
  const tg = state.telegram || {};
  const hint = tg.enabled ? '' : `<p class="subtext">Muốn biết ngay khi khách báo? ${btn('telegram-setup', 'Cài thông báo Telegram', 'secondary tiny')}</p>`;
  if (!rows.length) return state.lookup_supported && !tg.enabled ? `<section class="card report-card report-card-empty"><div class="section-heading"><div><h2>Khách báo mất Premium</h2><p>Khách tra cứu Gmail thấy nhóm vẫn bình thường mà mất Premium thì bấm báo cho shop. Báo lỗi hiện ở đây.</p></div></div>${hint}</section>` : '';
  const groups = [...new Map(rows.map(r => [r.family_id, []])).keys()].map(id => ({ id, rows: rows.filter(r => r.family_id === id) }));
  return `<section class="card report-card"><div class="section-heading"><div><h2>Khách báo mất Premium <span class="section-count">${rows.length}</span></h2><p>Nhiều khách cùng một Family báo thì thường là mail chủ bị quét: bấm <strong>Báo lỗi mail chủ</strong>. Nếu chỉ một khách bị, xử lý xong bấm <strong>Đã xử lý</strong> và để lại lời nhắn cho khách.</p></div></div>${hint}`
    + groups.map(group => {
      const family = state.families.find(f => f.id === group.id);
      const name = family ? family.name : group.rows[0].family_name;
      return `<div class="report-group"><div class="report-group-head"><div><strong>${family ? `<a class="email-link" href="#family/${family.id}">${escape(name)}</a>` : escape(name)}</strong>${family ? `<span class="subtext">${escape(family.manager_email)}</span>` : ''}</div><div class="row-actions">${family ? btn('report-family', 'Báo lỗi mail chủ', 'primary tiny', `data-id="${family.id}"`) : ''}${group.rows.length > 1 ? btn('customer-reports-handle', 'Đã xử lý tất cả', 'secondary tiny', `data-ids="${group.rows.map(r => r.id).join(',')}"`) : ''}</div></div>`
        + group.rows.map(r => `<div class="report-row"><div class="report-who">${ctx.customerInfo({ customer_name: (state.members.find(m => m.id === r.member_id) || {}).customer_name || '', email: r.email }, false)}</div><div class="report-what"><span class="badge amber">${escape(reasonLabel(state, r.reason))}</span>${r.note ? `<span class="subtext">“${escape(r.note)}”</span>` : ''}<span class="subtext">Báo lúc ${ctx.date(r.created_at)}</span></div><div class="row-actions">${btn('customer-reports-handle', 'Đã xử lý', 'secondary tiny', `data-ids="${r.id}"`)}</div></div>`).join('')
        + '</div>';
    }).join('') + '</section>';
}
function telegramCard(ctx) {
  const { state, escape, btn } = ctx, tg = state.telegram || {};
  return `<section class="card"><div class="section-heading"><div><h2>Thông báo Telegram</h2><p>${tg.enabled ? `Khi khách báo mất Premium, bot <strong>@${escape(tg.bot)}</strong> nhắn ngay cho <strong>${escape(tg.chat)}</strong>.` : 'Chưa bật. Bật để nhận tin trên điện thoại ngay khi khách báo mất Premium.'}</p></div><div class="row-actions">${tg.enabled ? btn('telegram-test', 'Gửi tin thử', 'secondary') + btn('telegram-setup', 'Đổi bot', 'secondary') + btn('telegram-off', 'Tắt', 'danger') : btn('telegram-setup', 'Cài thông báo Telegram', 'primary')}</div></div></section>`;
}

export function familyLookupSections(ctx, family) {
  if (!ctx.state.lookup_supported) return '';
  const { state, escape, btn } = ctx;
  const status = familyStatus(state, family.id), members = state.members.filter(m => m.family_id === family.id);
  // Links of a replaced owner stay stored (so Gmail never brings them back) but are not shown.
  const stored = (state.invites || []).filter(i => i.family_id === family.id), invites = stored.filter(i => i.holder_state !== 'retired');
  const ready = invites.filter(i => i.holder_state === 'ready').length, retired = stored.length - invites.length;
  const incoming = (state.moves || []).filter(m => m.to_family_id === family.id);
  const callout = problem(status.status) && members.length ? `<div class="notice lookup-callout"><div><strong>Nhóm đang có sự cố.</strong> Đã có Gmail chủ mới thì vào Fix lỗi → Đã fix → Đổi sang Gmail chủ mới: ${members.length} khách giữ nguyên trong Family này và tự nhận link mới khi tra cứu. Muốn dồn khách sang Family khác thì bấm nút bên cạnh.</div>${btn('move-open', 'Chuyển khách sang nhóm mới', 'primary', `data-id="${family.id}"`)}</div>` : '';
  return `<section class="card lookup-card"><div class="section-heading"><div><h2>Trạng thái cho khách</h2><p>Khách thấy trạng thái và lời nhắn này trên trang tra cứu.</p></div><div class="row-actions">${btn('family-status', 'Đổi trạng thái', 'secondary', `data-id="${family.id}"`)}</div></div><div class="lookup-status"><span class="badge ${statusColors[status.status]}">${escape(familyStatusLabels[status.status])}</span>${status.updated_at ? `<span class="subtext">Cập nhật ${ctx.date(status.updated_at)}</span>` : ''}<p>${escape(status.note || 'Chưa có lời nhắn cho khách.')}</p></div>${callout}</section>`
    + (problem(status.status) && !invites.length ? '' : `<section class="card lookup-card"><div class="section-heading"><div><h2>Link mời vào Family này <span class="section-count">${ready}/${invites.length}</span></h2><p>Khách <strong>Đã mời, chưa vào</strong>, <strong>Mua mới</strong> hoặc đang chờ link (sau khi đổi chủ hay chuyển nhóm) tra cứu Gmail sẽ tự nhận một link Sẵn sàng, kể cả khách đã quá hạn. Link đã đưa cho khách tự có tag <strong>Đã gửi</strong> và không giao cho ai khác.${retired ? ` Đã bỏ ${retired} link của chủ cũ.` : ''} ${state.gmail_import ? 'Google gửi thư mời mới thì bấm Lấy link mời; web tự thay link chưa dùng của đúng Gmail nhận thư.' : 'Google đổi link thì bấm Sửa và dán link mới.'}</p></div><div class="row-actions">${genMenu(ctx, family)}${state.gmail_import ? btn('invite-mails-fetch', 'Lấy link mời', 'primary', `data-id="${family.id}" title="Đọc thư mời trong Gmail và hiện link của từng mail đã tạo"`) : ''}${btn('invite-add', '+ Thêm link mời', 'secondary', `data-id="${family.id}"`)}</div></div>${pendingNotice(ctx, family)}${inviteTable(ctx, invites)}</section>`)
    + (incoming.length ? `<section class="card lookup-card"><div class="section-heading"><div><h2>Khách nhận link vào Family này</h2><p>Khách chuyển đến và khách mới tự nhận link khi tra cứu Gmail. Giao link là xong, không cần theo dõi khách đã vào hay chưa.</p></div></div>${moveTable(ctx, incoming)}</section>` : '');
}

export function lookupPage(ctx) {
  const { state, escape, btn } = ctx;
  if (!state.lookup_supported) return ctx.empty('Bản này chưa hỗ trợ trang tra cứu', 'Cập nhật ứng dụng lên bản mới nhất.');
  const settings = state.lookup_settings || {}, incidents = state.families.filter(f => problem(familyStatus(state, f.id).status));
  const moves = state.moves || [], open = moves.filter(m => ['assigned', 'opened', 'failed'].includes(m.effective_state)), waiting = open.filter(m => m.invite_id == null), handed = open.filter(m => m.invite_id != null);
  const link = lookupPageUrl(state);
  return ctx.hero('TRA CỨU KHÁCH', 'Tra cứu & chuyển nhóm', 'Khách nhập Gmail và mã tra cứu để xem tình trạng nhóm và lấy link vào nhóm mới.', ctx.copyButton(link, 'link trang tra cứu', 'Copy link trang') + ` <a class="secondary link-button" href="${escape(link)}" target="_blank" rel="noopener">Mở trang khách</a>` + (state.gmail_import ? ' ' + gmailButton(ctx) : ''))
    + `<div class="dashboard-summary stats"><div class="card stat"><h2>Family có sự cố</h2><strong>${incidents.length}</strong></div><div class="card stat"><h2>Khách chờ link</h2><strong>${waiting.length}</strong></div><div class="card stat"><h2>Khách đã nhận link</h2><strong>${handed.length}</strong></div></div>`
    + `<section class="card"><div class="section-heading"><div><h2>Family có sự cố</h2><p>Đặt trạng thái trong trang chi tiết Family.</p></div></div>${incidents.length ? `<div class="table-wrap"><table class="lookup-table"><thead><tr><th scope="col">FAMILY</th><th scope="col">TRẠNG THÁI</th><th scope="col">KHÁCH</th><th scope="col"></th></tr></thead><tbody>${incidents.map(f => { const s = familyStatus(state, f.id); return `<tr><td data-column="family"><a class="email-link" href="#family/${f.id}">${escape(f.name)}</a><span class="subtext">${escape(f.manager_email)}</span></td><td data-column="state"><span class="badge ${statusColors[s.status]}">${escape(familyStatusLabels[s.status])}</span><span class="subtext">${escape(s.note)}</span></td><td data-column="members">${familyOccupancy(state.members, f.id).label}</td><td data-column="actions"><a class="primary link-button tiny" href="#family/${f.id}">Mở Family</a></td></tr>`; }).join('')}</tbody></table></div>` : '<p class="muted">Tất cả Family đang hoạt động bình thường.</p>'}</section>`
    + `<section class="card"><div class="section-heading"><div><h2>Link đã giao cho khách</h2><p>Mới nhất trước. Khách chờ link sẽ tự nhận khi có link Sẵn sàng.</p></div></div>${moveTable(ctx, moves, true)}</section>`
    + telegramCard(ctx)
    + `<section class="card"><div class="section-heading"><div><h2>Thông tin hiển thị cho khách</h2><p>Tên shop và link liên hệ xuất hiện trên trang tra cứu.</p></div><div class="row-actions">${btn('lookup-settings', 'Sửa thông tin', 'secondary')}</div></div><div class="list-item"><strong>Tên shop</strong><p>${escape(settings.shop_name || 'Chưa đặt')}</p></div><div class="list-item"><strong>Link liên hệ</strong><p>${settings.contact_url ? `<a class="contact-link" href="${escape(settings.contact_url)}" target="_blank" rel="noopener noreferrer">${escape(settings.contact_label || settings.contact_url)}</a>` : 'Chưa đặt'}</p></div><div class="list-item"><strong>Ghi chú cho khách</strong><p>${escape(settings.help_text || 'Chưa có')}</p></div></section>`
    + `<section class="card"><h2>Cách dùng</h2><ol class="lookup-steps"><li>Gửi mỗi khách link tra cứu riêng (menu … của khách → <strong>Copy link tra cứu</strong>), ví dụ lúc bán hoặc gia hạn.</li><li>Khi mail chủ bị quét: <strong>Fix lỗi → Báo lỗi</strong>. Family tự thành Bị quét và khách thấy lời nhắn.</li><li>Có Gmail chủ mới: <strong>Đã fix → Đổi sang Gmail chủ mới</strong>, chọn số mail mời. Khách ở lại Family và chờ link của chủ mới.</li><li>Mời các mail vừa tạo từ Gmail chủ mới, rồi bấm <strong>Lấy link mời</strong>${state.gmail_import ? '' : ' (cần kết nối Google Sheet; hoặc <strong>+ Thêm link mời</strong> để dán tay)'}.</li><li>Khách mở link tra cứu, nhập Gmail để thấy link vào nhóm mới; theo dõi tiến độ tại đây.</li></ol></section>`;
}

function statusFields(ctx, family, status) {
  const { escape } = ctx;
  return `<div class="form-field"><label for="field-status">Trạng thái nhóm</label><select id="field-status" name="status">${Object.entries(familyStatusLabels).map(([key, text]) => `<option value="${key}" ${key === status.status ? 'selected' : ''}>${escape(text)}</option>`).join('')}</select></div><div class="form-field"><label for="field-note">Lời nhắn cho khách</label><textarea id="field-note" name="note" maxlength="1000" rows="5">${escape(status.note)}</textarea></div><p class="subtext">Khách chỉ thấy tên Family, trạng thái và lời nhắn này. Không hiện mail chủ hoặc khách khác.</p>`;
}
function inviteFields(ctx, invite = {}) {
  return ctx.input('label', 'Tên link / mail nhận lời mời', 'text', invite.label || '', false, 'maxlength="200" placeholder="ví dụ shopmail+1@gmail.com"')
    + ctx.input('url', 'Link nút “Chấp nhận lời mời”', 'url', invite.url || '', true, 'maxlength="2000" placeholder="https://…" autocomplete="off"')
    + ctx.input('sent_on', 'Ngày gửi lời mời', 'date', invite.sent_on ?? ctx.state.today)
    + '<p class="subtext">Lời mời Google hết hạn sau 2 tuần. Link phải là link https của Google (myaccount.google.com, families.google.com hoặc notifications.googleapis.com).</p>';
}
function mappingRows(ctx, source, targetId) {
  const { state, escape } = ctx;
  const members = sortCustomers(state.members.filter(m => m.family_id === source.id));
  const invites = readyInvites(state, targetId);
  let next = 0;
  const rows = members.map(m => {
    const pick = next < invites.length ? invites[next++].id : '';
    return `<tr><td data-column="customer"><strong>${escape(m.customer_name || m.email)}</strong>${m.customer_name ? `<span class="subtext">${escape(m.email)}</span>` : ''}</td><td data-column="expiry" class="date-cell"><strong class="date-value">${ctx.day(m.expires_at)}</strong><span class="subtext">${ctx.expiryBadge(m)}</span></td><td data-column="invite"><select name="invite_${m.id}" aria-label="Link mời cho ${escape(m.customer_name || m.email)}" data-move-member="${m.id}"><option value="">Không chuyển</option>${invites.map(i => `<option value="${i.id}" ${i.id === pick ? 'selected' : ''}>${escape(inviteName(ctx, i))}${i.expires_on ? ' · hết hạn ' + ctx.day(i.expires_on) : ''}</option>`).join('')}</select></td></tr>`;
  }).join('');
  return `<div class="table-wrap"><table class="lookup-table"><thead><tr><th scope="col">KHÁCH</th><th scope="col">HẠN DÙNG</th><th scope="col">LINK MỜI Ở FAMILY MỚI</th></tr></thead><tbody>${rows}</tbody></table></div>${invites.length ? '' : '<p class="error-box">Family này chưa có link mời sẵn sàng. Mở Family mới và bấm + Thêm link mời trước.</p>'}`;
}
// A Google Family holds the owner and 5 members: warn before the new Family would go over.
function updateMoveSummary(state) {
  const selects = [...document.querySelectorAll('#move-mapping select[data-move-member]')];
  const chosen = selects.map(s => s.value).filter(Boolean), duplicate = chosen.length !== new Set(chosen).size;
  const targetId = Number($('#move-target')?.value), already = state ? state.members.filter(m => m.family_id === targetId).length : 0, total = already + chosen.length;
  const over = !duplicate && total > 5;
  $('#move-summary').textContent = duplicate ? 'Một link đang được chọn cho nhiều khách. Mỗi link chỉ giao cho một khách.'
    : `Chuyển ${chosen.length} khách · giữ lại ${selects.length - chosen.length} khách ở Family cũ.` + (over ? ` Family mới sẽ có ${total} khách (đang có ${already}), quá 5 chỗ của Google Family. Bỏ chuyển bớt ${total - 5} khách hoặc chọn Family khác.` : '');
  $('#move-summary').classList.toggle('lookup-warning', duplicate || over);
}
function openBulkMove(ctx, sourceId) {
  const { state, escape } = ctx;
  const source = state.families.find(f => f.id === sourceId); if (!source) return ctx.toast('Family đã thay đổi. Tải lại trang.');
  const targets = state.families.filter(f => f.id !== source.id).map(f => ({ family: f, ready: readyInvites(state, f.id).length })).sort((a, b) => b.ready - a.ready);
  if (!targets.length) return ctx.toast('Tạo Family mới và thêm link mời trước khi chuyển khách.');
  const status = familyStatus(state, source.id);
  ctx.modal('Chuyển khách sang nhóm mới', `<p>Từ <strong>${escape(source.name)}</strong> · <span class="badge ${statusColors[status.status]}">${escape(familyStatusLabels[status.status])}</span></p><div class="form-field"><label for="move-target">Family mới</label><select id="move-target" name="to_family_id">${targets.map(t => `<option value="${t.family.id}">${escape(t.family.name)} · ${escape(t.family.manager_email)} · ${t.ready} link sẵn sàng · ${familyOccupancy(state.members, t.family.id).label}</option>`).join('')}</select></div><div id="move-mapping"></div><p id="move-summary" role="status"></p><p class="subtext">Khách được chuyển ở trạng thái Đã mời, chưa vào cho đến khi khách xác nhận hoặc bạn bấm Đã vào. Giữ nguyên gói, ngày mua/hạn, Contact, thanh toán và lịch sử. Case Fix lỗi gắn với mail khách được xóa như khi Chuyển Family.</p>`, async data => {
      const fresh = ctx.state, target = fresh.families.find(f => f.id === Number(data.to_family_id));
      if (!target) throw Error('Chọn Family mới.');
      const assignments = Object.entries(data).filter(([key, value]) => key.startsWith('invite_') && value).map(([key, value]) => {
        const member = fresh.members.find(m => m.id === Number(key.slice(7))), invite = (fresh.invites || []).find(i => i.id === Number(value));
        if (!member || !invite) throw Error('Dữ liệu đã thay đổi. Đóng hộp thoại, tải lại rồi thử lại.');
        return { member_id: member.id, revision: member.renewal_revision, expected_email: member.email, invite_id: invite.id, invite_revision: invite.revision };
      });
      if (!assignments.length) throw Error('Chọn link mời cho ít nhất một khách.');
      if (new Set(assignments.map(a => a.invite_id)).size !== assignments.length) throw Error('Mỗi link chỉ giao cho một khách.');
      const result = await ctx.post('moves', { from_family_id: source.id, to_family_id: target.id, expected_manager_email: target.manager_email, assignments });
      ctx.toast(`Đã chuyển ${result.moved} khách sang ${result.family_name}. Gửi khách link tra cứu để lấy link vào nhóm.`);
      return { route: 'family/' + result.family_id };
    }, 'Chuyển khách');
  const dialog = $('#modal'); dialog.classList.add('lookup-wide'); dialog.addEventListener('close', () => dialog.classList.remove('lookup-wide'), { once: true });
  const render = () => { $('#move-mapping').innerHTML = mappingRows(ctx, source, Number($('#move-target').value)); updateMoveSummary(ctx.state); };
  $('#move-target').addEventListener('change', render);
  $('#move-mapping').addEventListener('change', () => updateMoveSummary(ctx.state));
  render();
}

// Returns true when the action belongs to this module.
export async function handleLookupAction(ctx, action, button) {
  const { state } = ctx, id = Number(button.dataset.id);
  if (action === 'customer-reports-handle') {
    const ids = String(button.dataset.ids || '').split(',').map(Number), rows = ids.map(i => (state.customer_reports || []).find(r => r.id === i && !r.handled_at));
    if (!rows.length || rows.some(r => !r)) return ctx.toast('Báo lỗi đã thay đổi. Tải lại trang.'), true;
    ctx.modal(rows.length > 1 ? `Đã xử lý ${rows.length} báo lỗi` : 'Đã xử lý báo lỗi', `<p>${rows.map(r => ctx.escape(r.email)).join(', ')}</p><div class="form-field"><label for="field-note">Lời nhắn cho khách (không bắt buộc)</label><textarea id="field-note" name="note" maxlength="500" rows="3" placeholder="Ví dụ: Shop đã mời lại bạn, kiểm tra Gmail rồi bấm chấp nhận."></textarea></div><p class="subtext">Khách thấy lời nhắn này trên trang tra cứu trong 3 ngày.</p>`, async data => {
      for (const r of rows) await ctx.patch(`customer-reports/${r.id}`, { revision: r.revision, note: data.note || '' });
      ctx.toast(rows.length > 1 ? `Đã xử lý ${rows.length} báo lỗi.` : 'Đã xử lý báo lỗi.');
    }, 'Đã xử lý');
    return true;
  }
  if (action === 'telegram-setup') {
    const tg = state.telegram || {};
    ctx.modal('Cài thông báo Telegram', `<ol class="lookup-steps telegram-steps"><li>Mở Telegram, tìm <strong>@BotFather</strong>, gửi <code>/newbot</code>. Đặt tên (ví dụ <em>Hải Premium thông báo</em>) và tên đăng nhập kết thúc bằng <em>bot</em>.</li><li>BotFather gửi một mã dạng <code>123456789:AAE…</code>. Copy và dán vào ô dưới.</li><li>Bấm vào link bot BotFather gửi (t.me/…), rồi bấm <strong>Bắt đầu / Start</strong>. Muốn nhận tin trong nhóm chat thì thêm bot vào nhóm và gửi một tin bất kỳ.</li><li>Bấm <strong>Kết nối</strong>. Web gửi một tin thử về Telegram của bạn.</li></ol>`
      + ctx.input('token', 'Mã bot (token)', 'text', '', !tg.enabled, `maxlength="120" autocomplete="off" spellcheck="false" placeholder="${tg.enabled ? 'Để trống để giữ bot hiện tại' : '123456789:AAE…'}"`)
      + '<p class="subtext">Mã bot chỉ lưu trên máy chủ của bạn, không hiện lại trên web.</p>', async data => {
      const result = await ctx.post('telegram', { token: data.token || '' });
      ctx.toast(`Đã kết nối @${result.telegram.bot}. Kiểm tra tin thử trên Telegram.`);
    }, 'Kết nối');
    return true;
  }
  if (action === 'telegram-test') { try { await ctx.post('telegram/test', {}); ctx.toast('Đã gửi tin thử. Kiểm tra Telegram.'); } catch (error) { ctx.toast(error.message); } return true; }
  if (action === 'telegram-off') {
    ctx.modal('Tắt thông báo Telegram?', '<p>Khách vẫn báo mất Premium được và báo lỗi vẫn hiện ở Fix lỗi, chỉ không gửi tin Telegram nữa.</p>', async () => { await ctx.api('telegram', { method: 'DELETE', body: '{}' }); ctx.toast('Đã tắt thông báo Telegram.'); }, 'Tắt');
    return true;
  }
  if (action === 'family-status') {
    const family = state.families.find(f => f.id === id); if (!family) return ctx.toast('Family đã thay đổi. Tải lại trang.'), true;
    const status = familyStatus(state, id);
    ctx.modal('Trạng thái cho khách · ' + family.name, statusFields(ctx, family, status), async data => {
      await ctx.patch(`families/${id}/status`, { status: data.status, note: data.note, revision: status.revision });
      ctx.toast('Đã lưu trạng thái nhóm. Khách thấy ngay trên trang tra cứu.');
    });
    $('#field-status').addEventListener('change', event => { const note = $('#field-note'); if (!note.value.trim() && statusTemplates[event.target.value]) note.value = statusTemplates[event.target.value](family.name); });
    return true;
  }
  if (action === 'invite-add') {
    const family = state.families.find(f => f.id === id); if (!family) return ctx.toast('Family đã thay đổi. Tải lại trang.'), true;
    ctx.modal('Thêm link mời · ' + family.name, inviteFields(ctx), async data => { await ctx.post(`families/${id}/invites`, data); ctx.toast('Đã thêm link mời.'); });
    return true;
  }
  if (action === 'invite-edit') {
    const invite = (state.invites || []).find(i => i.id === id); if (!invite) return ctx.toast('Link đã thay đổi. Tải lại trang.'), true;
    ctx.modal('Sửa link mời', inviteFields(ctx, invite) + (invite.holder_state === 'assigned' ? `<p class="notice">Link đang giao cho ${ctx.escape(invite.holder_name || invite.holder_email)}. Dán link mới thì khách thấy link mới ngay khi tra cứu.</p>` : ''), async data => { await ctx.patch('invites/' + id, { ...data, revision: invite.revision }); ctx.toast('Đã lưu link mời.'); });
    return true;
  }
  if (action === 'invite-delete') {
    const invite = (state.invites || []).find(i => i.id === id); if (!invite) return ctx.toast('Link đã thay đổi. Tải lại trang.'), true;
    ctx.modal('Xóa link mời?', `<p>${ctx.escape(inviteName(ctx, invite))}</p><p>Chỉ xóa link khỏi kho của Family. Lời mời trên Google vẫn còn cho đến khi hết hạn.</p>`, async () => { await ctx.api('invites/' + id, { method: 'DELETE', body: JSON.stringify({ revision: invite.revision }) }); ctx.toast('Đã xóa link mời.'); }, 'Xóa link');
    return true;
  }
  if (action === 'move-open') { openBulkMove(ctx, id); return true; }
  if (action === 'invite-unsend') {
    const invite = (state.invites || []).find(i => i.id === id); if (!invite) return ctx.toast('Link đã thay đổi. Tải lại trang.'), true;
    ctx.modal('Đưa link lại vào kho?', `<p>${ctx.escape(inviteName(ctx, invite))}</p><p>Link này đã hiện cho một khách trước đó. Chỉ đưa lại vào kho khi chắc chắn chưa ai dùng; khách tra cứu tiếp theo có thể nhận link này.</p>`, async () => {
      await ctx.patch(`invites/${id}/sent`, { sent: false, revision: invite.revision }); ctx.toast('Link quay lại Sẵn sàng.');
    }, 'Đưa lại vào kho');
    return true;
  }
  if (action === 'invite-mails-gen') {
    const family = state.families.find(f => f.id === id); if (!family) return ctx.toast('Family đã thay đổi. Tải lại trang.'), true;
    const menu = button.closest('details'); if (menu) menu.open = false;
    button.disabled = true;
    try { const result = await createInviteMails(ctx, family.id, button.dataset.count); await ctx.refresh(); showInviteMails(ctx, result); }
    catch (error) { ctx.toast(error.message, 8000); }
    finally { if (button.isConnected) button.disabled = false; }
    return true;
  }
  if (action === 'invite-mails-delete') {
    const ids = String(button.dataset.mails || '').split(',').map(Number).filter(Boolean), mails = (state.invite_mails || []).filter(m => ids.includes(m.id));
    if (!mails.length) return ctx.toast('Mail mời đã thay đổi. Tải lại trang.'), true;
    ctx.modal(mails.length > 1 ? `Xóa ${mails.length} mail mời?` : 'Xóa mail mời?', `<div class="lookup-mail-list">${mails.map(m => `<div class="info-line"><span class="info-text">${ctx.escape(m.email)}</span></div>`).join('')}</div><p>Chỉ xóa khỏi danh sách chờ lấy link trên web. Nếu đã mời mail này từ tài khoản chủ, lời mời trên Google vẫn còn.</p>`, async () => {
      const result = await ctx.api(`families/${id}/invite-mails`, { method: 'DELETE', body: JSON.stringify({ ids }) }); ctx.toast(`Đã xóa ${result.deleted} mail mời.`);
    }, 'Xóa');
    return true;
  }
  if (action === 'invite-mails-fetch') {
    const family = state.families.find(f => f.id === id); if (!family) return ctx.toast('Family đã thay đổi. Tải lại trang.'), true;
    button.disabled = true;
    try { const result = await ctx.post('sheets/gmail-invites', {}); await ctx.refresh(); showFetchedMails(ctx, ctx.state.families.find(f => f.id === id) || family, result); }
    catch (error) { ctx.toast(error.message, 12000); }
    finally { if (button.isConnected) button.disabled = false; }
    return true;
  }
  if (action === 'invites-gmail') {
    button.disabled = true;
    try { const result = await ctx.post('sheets/gmail-invites', {}); ctx.toast(gmailSummary(result), 9000); await ctx.refresh(); }
    catch (error) { ctx.toast(error.message, 12000); }
    finally { if (button.isConnected) button.disabled = false; }
    return true;
  }
  const move = (state.moves || []).find(m => m.id === id);
  if (['move-joined', 'move-release', 'move-reassign', 'move-dismiss', 'move-unassign'].includes(action) && !move) return ctx.toast('Lượt chuyển nhóm đã thay đổi. Tải lại trang.'), true;
  if (action === 'move-joined') {
    ctx.modal('Ghi nhận khách đã vào nhóm?', `${ctx.customerInfo(move, false)}<p>${ctx.escape(move.to_family_name)} · ${ctx.escape(move.invite_label)}</p><p>Khách chuyển sang đang ở nhóm và link được đánh dấu đã dùng.</p>`, async () => { await ctx.patch('moves/' + id, { action: 'joined', revision: move.revision }); ctx.toast('Đã ghi nhận khách vào nhóm.'); }, 'Đã vào nhóm');
    return true;
  }
  if (action === 'move-unassign') {
    ctx.modal('Thu hồi link về kho?', `${ctx.customerInfo(move, false)}<p>Link ${ctx.escape(move.invite_label)} trở về Sẵn sàng và được giao cho khách tra cứu tiếp theo. Khách này chờ link mới: mở lại trang tra cứu sẽ thấy Shop đang chuẩn bị link.</p>`, async () => {
      await ctx.patch(`moves/${move.id}`, { action: 'unassign', revision: move.revision });
      ctx.toast('Đã thu hồi link về kho.');
    }, 'Thu hồi về kho');
    return true;
  }
  if (action === 'move-release') {
    ctx.modal('Thu hồi link?', `${ctx.customerInfo(move, false)}<p>Link ${ctx.escape(move.invite_label)} quay lại kho của ${ctx.escape(move.to_family_name)} để giao cho khách khác. Khách vẫn ở Family mới với trạng thái Đã mời, chưa vào; sửa hoặc chuyển khách như bình thường.</p>`, async () => { await ctx.patch('moves/' + id, { action: 'release', revision: move.revision }); ctx.toast('Đã thu hồi link về kho.'); }, 'Thu hồi link');
    return true;
  }
  if (action === 'move-reassign') {
    const invites = readyInvites(state, move.to_family_id);
    if (!invites.length) return ctx.toast(`${move.to_family_name} chưa có link sẵn sàng. Thêm link mời trước.`), true;
    ctx.modal('Đổi link cho khách', `${ctx.customerInfo(move, false)}<p>Link hiện tại: ${ctx.escape(move.invite_label || '—')}</p>` + ctx.select('invite_id', 'Link mới', Object.fromEntries(invites.map(i => [i.id, inviteName(ctx, i) + (i.expires_on ? ' · hết hạn ' + ctx.day(i.expires_on) : '')])), invites[0].id) + '<p class="subtext">Link cũ quay lại kho. Nếu link cũ đã bị dùng, hãy xóa nó khỏi kho.</p>', async data => {
      const invite = (ctx.state.invites || []).find(i => i.id === Number(data.invite_id)); if (!invite) throw Error('Chọn link mới.');
      await ctx.patch('moves/' + id, { action: 'reassign', invite_id: invite.id, invite_revision: invite.revision, revision: move.revision }); ctx.toast('Đã đổi link cho khách.');
    }, 'Đổi link');
    return true;
  }
  if (action === 'move-dismiss') { await ctx.patch('moves/' + id, { action: 'dismiss', revision: move.revision }); await ctx.refresh(); return true; }
  if (action === 'lookup-rotate') {
    const address = button.dataset.email;
    ctx.modal('Đổi mã tra cứu?', `<p>${ctx.escape(address)}</p><p>Mã cũ và link tra cứu cũ hết tác dụng ngay; khách đang mở trang sẽ phải nhập lại. Dùng khi mã bị lộ hoặc gửi nhầm người.</p>`, async () => {
      const result = await ctx.post('lookup-codes', { email: address }); ctx.toast(`Mã mới của ${result.email}: ${result.code}. Copy link tra cứu để gửi lại cho khách.`, 10000);
    }, 'Đổi mã');
    return true;
  }
  if (action === 'lookup-settings') {
    const s = state.lookup_settings || {};
    ctx.modal('Thông tin trang tra cứu', ctx.input('shop_name', 'Tên shop', 'text', s.shop_name, false, 'maxlength="100"') + ctx.input('contact_url', 'Link liên hệ (Messenger, Zalo…)', 'url', s.contact_url, false, 'maxlength="500" placeholder="https://m.me/…"') + ctx.input('contact_label', 'Chữ trên nút liên hệ', 'text', s.contact_label, false, 'maxlength="60" placeholder="Nhắn shop"') + `<div class="form-field"><label for="field-help_text">Ghi chú cho khách</label><textarea id="field-help_text" name="help_text" maxlength="500" placeholder="ví dụ Shop phản hồi trong 30 phút, 8h–22h.">${ctx.escape(s.help_text)}</textarea></div>` + ctx.input('short_domain', 'Link ngắn (không bắt buộc)', 'text', s.short_domain, false, 'maxlength="200" placeholder="ví dụ beeflix.vn/haiytb" autocapitalize="none" spellcheck="false"') + ctx.input('reclaim_days', 'Tự thu hồi link khách chưa bấm sau (ngày)', 'number', s.reclaim_days === '' || s.reclaim_days === undefined ? '3' : s.reclaim_days, false, 'min="0" max="30" step="1"') + '<p class="subtext">Khi Family hết link Sẵn sàng, link đã giao mà khách chưa bấm Vào nhóm mới sau số ngày này được giao cho khách tiếp theo. Điền 0 để tắt.</p>'
      + '<p class="subtext">Tên miền phụ (có thể kèm đường dẫn) đã chuyển hướng về website này. Link gửi khách sẽ thành beeflix.vn/haiytb?MÃ. Để trống thì dùng tên miền website.</p>', async data => { await ctx.patch('lookup-settings', data); ctx.toast('Đã lưu thông tin trang tra cứu.'); });
    return true;
  }
  return false;
}
