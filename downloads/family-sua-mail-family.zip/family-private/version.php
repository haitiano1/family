<?php return ['version'=>'0.28.7','schema'=>8,'protocol'=>1];
