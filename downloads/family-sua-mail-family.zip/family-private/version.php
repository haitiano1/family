<?php return ['version'=>'0.32.3','schema'=>8,'protocol'=>1];
